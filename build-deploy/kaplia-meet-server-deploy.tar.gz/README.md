# Kaplia Meet

Minimal Electron MVP for private 1-on-1 WebRTC calls. The VPS is used only for WebSocket signaling and STUN/TURN. Audio/video media goes through direct WebRTC P2P when possible, or through coturn relay when NAT/CGNAT blocks direct ICE connectivity. Media content is protected by WebRTC DTLS-SRTP end-to-end encryption between peers.

## Architecture

- `app/` is the Electron client with a Vite renderer.
- `server/` is a Node.js signaling server using Express + WebSocket.
- `deploy/` contains Docker Compose, Caddy reverse proxy, and coturn config examples.
- Rooms are in-memory and limited to 2 participants.
- The server does not store audio, video, chat, or call content.
- `/rooms` creates room IDs and is rate limited.
- `/ice-config` returns STUN/TURN config with temporary TURN REST credentials.
- `/health` is a lightweight health endpoint.

## Local Development

Start the signaling server:

```bash
cd server
cp .env.example .env
npm install
npm run dev
```

Start the Electron app in another terminal:

```bash
cd app
npm install
npm run dev
```

Local dev defaults to:

- Signaling WebSocket: `ws://localhost:8080/ws`
- Renderer origin: `http://127.0.0.1:5173`
- ICE config: `http://localhost:8080/ice-config`

For local development without coturn, leave `TURN_HOST` and `TURN_SECRET` empty in `server/.env`; the server will return a public STUN fallback only.

## Configure The Server URL In Electron

For development, override the runtime URL:

```bash
cd app
KAPLIA_SIGNALING_URL=wss://meet.kaplia.pro/ws npm run dev
```

For distributable macOS/Windows builds, edit `app/electron/config.js` before building:

```js
module.exports = {
  defaultSignalingUrl: "wss://meet.kaplia.pro/ws"
};
```

Use a domain with a valid TLS certificate for production WSS. A raw public IP can work only if you provide a trusted certificate for it, which is usually less convenient than DNS + Caddy.

## Ubuntu 24.04 VPS Deployment

Point a DNS record such as `meet.kaplia.pro` to the VPS public IP `167.233.126.127`.

If you use the same hostname for signaling and TURN/STUN, set the Cloudflare DNS record to **DNS only**. Cloudflare orange-cloud proxying does not proxy normal TURN/STUN traffic on `3478/5349` UDP/TCP.

Install Docker and UFW:

```bash
sudo apt update
sudo apt install -y ca-certificates curl ufw
curl -fsSL https://get.docker.com | sudo sh
sudo usermod -aG docker "$USER"
```

Log out and back in so the Docker group applies.

Configure firewall:

```bash
sudo ufw allow OpenSSH
sudo ufw allow 80/tcp
sudo ufw allow 443/tcp
sudo ufw allow 3478/tcp
sudo ufw allow 3478/udp
sudo ufw allow 5349/tcp
sudo ufw allow 5349/udp
sudo ufw allow 49152:65535/udp
sudo ufw enable
sudo ufw status
```

Configure environment:

```bash
cp server/.env.example server/.env
cp deploy/.env.example deploy/.env
cp deploy/coturn/turnserver.conf.example deploy/coturn/turnserver.conf
openssl rand -base64 32
```

Set these values:

- `deploy/.env`: `MEET_DOMAIN=meet.kaplia.pro`
- `server/.env`: `TURN_HOST=meet.kaplia.pro`
- `server/.env`: `TURN_REALM=meet.kaplia.pro`
- `server/.env`: `TURN_SECRET=<the openssl value>`
- `server/.env`: `ALLOWED_ORIGINS=app://kaplia-meet,http://localhost:5173,http://127.0.0.1:5173`
- `deploy/coturn/turnserver.conf`: `external-ip=167.233.126.127`
- `deploy/coturn/turnserver.conf`: `realm=meet.kaplia.pro`
- `deploy/coturn/turnserver.conf`: `server-name=meet.kaplia.pro`
- `deploy/coturn/turnserver.conf`: `static-auth-secret=<same TURN_SECRET>`

Start services:

```bash
cd deploy
docker compose up -d --build
docker compose ps
```

Check HTTPS/WSS-facing endpoints:

```bash
curl https://meet.kaplia.pro/health
curl https://meet.kaplia.pro/ice-config
```

`/ice-config` should return `turnAvailable: true` in production. Do not paste the returned TURN credential into logs or public tickets.

## TURN/STUN Notes

coturn listens on:

- `3478/udp` and `3478/tcp` for STUN/TURN
- `5349/tcp` and optionally `5349/udp` for TURN over TLS/DTLS if you mount valid certs
- `49152-65535/udp` as the relay port range

The server generates temporary TURN credentials using the TURN REST API style:

```text
username = <unix-expiry>:<random>
password = base64(hmac-sha1(TURN_SECRET, username))
```

The Electron client never receives `TURN_SECRET`; it only receives temporary `username` and `credential` values from `/ice-config`.

To verify TURN:

1. Confirm `curl https://meet.kaplia.pro/ice-config` returns `turn:` URLs and `turnAvailable: true`.
2. Use the WebRTC Trickle ICE sample at `https://webrtc.github.io/samples/src/content/peerconnection/trickle-ice/` with the temporary URL, username, and credential from `/ice-config`.
3. Start a call from two different networks. The room screen will show `Connected, relayed via TURN` when WebRTC stats expose a selected relay candidate.

## Build Electron Apps

Install app dependencies:

```bash
cd app
npm install
```

Build renderer assets:

```bash
npm run build
```

macOS DMG:

```bash
npm run dist:mac
```

Windows EXE:

```bash
npm run dist:win
```

Windows builds are most reliable on Windows or CI. Cross-building from macOS can require extra tooling and may not produce signed installers.

Artifacts are written to `app/dist/`.

## Signaling Protocol

Client to server:

- `join`: join an existing room.
- `signal`: forward WebRTC offer, answer, or ICE candidate to the other participant.
- `leave`: leave the room.

Server to client:

- `joined`: room join confirmed.
- `peer-joined`: the second participant arrived; existing peer creates the offer.
- `signal`: forwarded WebRTC signaling payload.
- `peer-left`: the other participant disconnected or left.
- `error`: validation, full room, or room-not-found errors.

## Security Defaults

- Secrets live in `.env`; TURN secrets are never hardcoded in the Electron client.
- Signaling origin checks are controlled by `ALLOWED_ORIGINS`.
- Room creation is rate limited by `CREATE_ROOM_LIMIT_PER_MINUTE`.
- Room IDs are validated server-side and client-side.
- Room state is in-memory and expires after `ROOM_EMPTY_TTL_SECONDS` when empty.
- HTTPS/WSS is terminated by Caddy.
